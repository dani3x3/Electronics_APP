package Electronic_APP;

public class LineaBlanca {
    private Producto lavadora;
    private Producto refrigeradora;
    private Producto microondas;

    public LineaBlanca(Producto lavadora, Producto refrigeradora, Producto microondas) {
        this.lavadora = lavadora;
        this.refrigeradora = refrigeradora;
        this.microondas = microondas;
    }

    // Métodos para obtener los productos de línea blanca
    public Producto getLavadora() {
        return lavadora;
    }

    public Producto getRefrigeradora() {
        return refrigeradora;
    }

    public Producto getMicroondas() {
        return microondas;
    }
}
