package Electronic_APP;

public class LineaMarron {
    private Producto televisores;
    private Producto equiposSonido;
    private Producto cinemaEnCasa;

    public LineaMarron(Producto televisores, Producto equiposSonido, Producto cinemaEnCasa) {
        this.televisores = televisores;
        this.equiposSonido = equiposSonido;
        this.cinemaEnCasa = cinemaEnCasa;
    }

    // Métodos para obtener los productos de la línea marron
    public Producto getTelevisores() {
        return televisores;
    }

    public Producto getEquiposSonido() {
        return equiposSonido;
    }

    public Producto getCinemaEnCasa() {
        return cinemaEnCasa;
    }
}
