package Electronic_APP;

import java.util.Scanner;

public class Electronic_APP {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Bienvenido al sistema de gestión de inventarios Electronic_APP");
            System.out.println("Por favor, seleccione la línea de venta:");
            System.out.println("1. Linea blanca");
            System.out.println("2. Linea electro");
            System.out.println("3. Linea Marron");

            int lineaSeleccionada = scanner.nextInt();

            double descuento = 0.0;

            // Aplicar descuento según la tarjeta del cliente
            System.out.println("Por favor, seleccione el tipo de tarjeta del cliente:");
            System.out.println("1. Tarjeta verde");
            System.out.println("2. Tarjeta gris");
            System.out.println("3. Tarjeta negra");
            System.out.println("4. Otra casa comercial");

            int tipoTarjeta = scanner.nextInt();

            switch (tipoTarjeta) {
                case 1:
                    descuento = 0.20;
                    break;
                case 2:
                    descuento = 0.30;
                    break;
                case 3:
                    descuento = 0.40;
                    break;
                case 4:
                    // Otra casa comercial, no se aplica descuento
                    descuento = 0.0;
                    break;
                default:
                    System.out.println("Tipo de tarjeta no válido. No se aplicará ningún descuento.");
            }

            // Aplicar descuento adicional si el pago es al contado
            System.out.println("¿El pago es al contado? (S/N)");
            String respuestaPago = scanner.next();
            if (respuestaPago.equalsIgnoreCase("S")) {
                // Aplicar 10% de descuento adicional
                descuento += 0.10;
            }

            switch (lineaSeleccionada) {
                case 1:
                    gestionarLineaBlanca(descuento);
                    break;
                case 2:
                    gestionarLineaElectro(descuento);
                    break;
                case 3:
                    gestionarLineaMarron(descuento);
                    break;
                default:
                    System.out.println("Línea de venta no válida.");
            }
        }
    }

    public static void gestionarLineaBlanca(double descuento) {
        // Aquí iría la lógica para gestionar la línea de productos de línea blanca
        System.out.println("Gestionando línea blanca con descuento del " + (descuento * 100) + "%");
    }

    public static void gestionarLineaElectro(double descuento) {
        // Aquí iría la lógica para gestionar la línea de productos electrónicos
        System.out.println("Gestionando línea electro con descuento del " + (descuento * 100) + "%");
    }

    public static void gestionarLineaMarron(double descuento) {
        // Aquí iría la lógica para gestionar la línea de productos marrones
        System.out.println("Gestionando línea marron con descuento del " + (descuento * 100) + "%");
    }
}
