package Electronic_APP;

public class LineaElectro {
    private Producto audifonos;
    private Producto computadoras;
    private Producto smartphones;

    public LineaElectro(Producto audifonos, Producto computadoras, Producto smartphones) {
        this.audifonos = audifonos;
        this.computadoras = computadoras;
        this.smartphones = smartphones;
    }

    // Métodos para obtener los productos de la línea electro
    public Producto getAudifonos() {
        return audifonos;
    }

    public Producto getComputadoras() {
        return computadoras;
    }

    public Producto getSmartphones() {
        return smartphones;
    }
}
